package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;
import java.util.List;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NONE
)
public class Product implements IProduct {
  private String id;

  private List<IReview> reviews;

  public Product() {
  }

  @Override
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  @Override
  public List<IReview> getReviews() {
    return reviews;
  }

  public void setReviews(List<IReview> reviews) {
    this.reviews = reviews;
  }

  @Override
  public String toString() {
    return "Product{" + "id='" + id + "'," +"reviews='" + reviews + "'" +"}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product that = (Product) o;
        return java.util.Objects.equals(id, that.id) &&
                            java.util.Objects.equals(reviews, that.reviews);
  }

  @Override
  public int hashCode() {
    return java.util.Objects.hash(id, reviews);
  }

  public static com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder newBuilder(
      ) {
    return new Builder();
  }

  public static class Builder {
    private String id;

    private List<IReview> reviews;

    public Product build() {
                  com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product result = new com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product();
                      result.id = this.id;
          result.reviews = this.reviews;
                      return result;
    }

    public com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder id(
        String id) {
      this.id = id;
      return this;
    }

    public com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder reviews(
        List<IReview> reviews) {
      this.reviews = reviews;
      return this;
    }
  }
}
