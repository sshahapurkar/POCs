package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NONE
)
public class Review implements IReview {
  private int starRating;

  public Review() {
  }

  @Override
  public int getStarRating() {
    return starRating;
  }

  public void setStarRating(int starRating) {
    this.starRating = starRating;
  }

  @Override
  public String toString() {
    return "Review{" + "starRating='" + starRating + "'" +"}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Review that = (Review) o;
        return starRating == that.starRating;
  }

  @Override
  public int hashCode() {
    return java.util.Objects.hash(starRating);
  }

  public static com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Review.Builder newBuilder(
      ) {
    return new Builder();
  }

  public static class Builder {
    private int starRating;

    public Review build() {
      com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Review result = new com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Review();
          result.starRating = this.starRating;
          return result;
    }

    public com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Review.Builder starRating(
        int starRating) {
      this.starRating = starRating;
      return this;
    }
  }
}
