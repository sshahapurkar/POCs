package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types;

public interface IReview {
  int getStarRating();
}
