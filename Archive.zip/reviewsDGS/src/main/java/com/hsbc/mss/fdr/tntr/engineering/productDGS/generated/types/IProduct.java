package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types;

import java.lang.String;
import java.util.List;

public interface IProduct {
  String getId();

  List<? extends IReview> getReviews();
}
