package com.hsbc.mss.fdr.tntr.engineering.productDGS.datafetchers;

import com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product;
import com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Review;
import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsData;
import com.netflix.graphql.dgs.DgsDataFetchingEnvironment;
import com.netflix.graphql.dgs.DgsEntityFetcher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@DgsComponent
public class ReviewsDatafetcher {

    Map<String, List<Review>> reviews = new HashMap<>();

    public ReviewsDatafetcher() {
        List<Review> review1 = new ArrayList<>();
        Review r1 = Review.newBuilder().starRating(1)
                        .build();
        Review r2 = Review.newBuilder().starRating(2)
                        .build();
        review1.add(r1);
        review1.add(r2);

        reviews.put("1", review1);

        List<Review> review2 = new ArrayList<>();
        review2.add(r1);
        review2.add(r2);

        reviews.put("2", review2);
    }

    @DgsEntityFetcher(name = "Product")
    public Product movie(Map<String, Object> values) {
        String s = (String)values.get("id");
        Product pp = Product.newBuilder().id(s)
                .build();
        return pp;

        //return new Product((String) values.get("id"), null);
    }

    @DgsData(parentType = "Product", field = "reviews")
    public List<Review> reviewsFetcher(DgsDataFetchingEnvironment dataFetchingEnvironment)  {
        Product product = dataFetchingEnvironment.getSource();
        return reviews.get(product.getId());
    }
}
