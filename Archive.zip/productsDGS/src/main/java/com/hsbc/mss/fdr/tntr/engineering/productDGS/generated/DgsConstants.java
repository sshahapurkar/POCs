package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated;

import java.lang.String;

public class DgsConstants {
  public static final String QUERY_TYPE = "Query";

  public static class QUERY {
    public static final String TYPE_NAME = "Query";

    public static final String Products = "products";

    public static class PRODUCTS_INPUT_ARGUMENT {
      public static final String NameFilter = "nameFilter";
    }
  }

  public static class PRODUCT {
    public static final String TYPE_NAME = "Product";

    public static final String Id = "id";

    public static final String Name = "name";

    public static final String Description = "description";
  }
}
