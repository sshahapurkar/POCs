package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.datafetchers;

import com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product;
import com.hsbc.mss.fdr.tntr.engineering.productDGS.services.ProductService;
import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsData;
import graphql.schema.DataFetchingEnvironment;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@DgsComponent
public class ProductsDatafetcher {

  @Autowired
  ProductService productService;

  @DgsData(
      parentType = "Query",
      field = "products"
  )
  public List<Product> getProducts(DataFetchingEnvironment dataFetchingEnvironment) {
    return productService.listOfProduct();
  }
}
