package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types;

import java.lang.String;

public interface IProduct {
  String getId();

  String getName();

  String getDescription();
}
