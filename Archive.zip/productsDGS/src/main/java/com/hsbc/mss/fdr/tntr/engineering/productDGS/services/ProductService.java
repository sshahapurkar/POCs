package com.hsbc.mss.fdr.tntr.engineering.productDGS.services;


import com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

interface IProductService {
    public List<Product> listOfProduct();
}

@Service
public class ProductService implements IProductService{
    @Override
    public List<Product> listOfProduct() {
        ArrayList list = new ArrayList();
        Product p = Product.newBuilder().id("1")
                .name("samsung mobile")
                .build();
        list.add(p);
        return list;
    }
}
