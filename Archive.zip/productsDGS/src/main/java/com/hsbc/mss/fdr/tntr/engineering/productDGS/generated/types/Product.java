package com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types;

import com.fasterxml.jackson.annotation.JsonTypeInfo;
import java.lang.Object;
import java.lang.Override;
import java.lang.String;

@JsonTypeInfo(
    use = JsonTypeInfo.Id.NONE
)
public class Product implements IProduct {
  private String id;

  private String name;

  private String description;

  public Product() {
  }

  @Override
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  @Override
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  @Override
  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  @Override
  public String toString() {
    return "Product{" + "id='" + id + "'," +"name='" + name + "'," +"description='" + description + "'" +"}";
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product that = (Product) o;
        return java.util.Objects.equals(id, that.id) &&
                            java.util.Objects.equals(name, that.name) &&
                            java.util.Objects.equals(description, that.description);
  }

  @Override
  public int hashCode() {
    return java.util.Objects.hash(id, name, description);
  }

  public static com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder newBuilder(
      ) {
    return new Builder();
  }

  public static class Builder {
    private String id;

    private String name;

    private String description;

    public Product build() {
                  com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product result = new com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product();
                      result.id = this.id;
          result.name = this.name;
          result.description = this.description;
                      return result;
    }

    public com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder id(
        String id) {
      this.id = id;
      return this;
    }

    public com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder name(
        String name) {
      this.name = name;
      return this;
    }

    public com.hsbc.mss.fdr.tntr.engineering.productDGS.generated.types.Product.Builder description(
        String description) {
      this.description = description;
      return this;
    }
  }
}
